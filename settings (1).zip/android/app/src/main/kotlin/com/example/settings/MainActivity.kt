package com.example.settings

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
