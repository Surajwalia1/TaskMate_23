package com.example.sighin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
