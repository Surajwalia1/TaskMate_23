import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text('Spaces')),
        body: Container(
          child: GridView.count(
            crossAxisCount: 2,
            children: <Widget>[
              _buildGridTile('Task', Colors.blue, 'assets/task.png', context),
              _buildGridTile(
                  'Bookmark', Colors.green, 'assets/bookmark.png', context),
              _buildGridTile(
                  'Calendar', Colors.orange, 'assets/calendar.png', context),
              _buildGridTile(
                  'Fitness', Colors.red, 'assets/fitness.png', context),
              _buildGridTile(
                  'Notes', Colors.purple, 'assets/mood.png', context),
              _buildGridTile(
                  'Diary', Colors.yellow, 'assets/diary.png', context),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildGridTile(
      String title, Color color, String imagePath, BuildContext context) {
    return InkWell(
      onTap: () {
        // Navigate to a new screen when the container is clicked
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => DetailScreen(title: title)),
        );
      },
      child: Container(
        margin: EdgeInsets.all(10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: color,
        ),
        child: Stack(
          children: [
            Positioned(
              top: 10,
              left: 10,
              child: Text(
                title,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 25,
                  fontFamily: "Urbanist",
                ),
              ),
            ),
            Positioned(
              bottom: 10,
              right: 10,
              child: Image.asset(
                imagePath,
                width: 60,
                height: 60,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class DetailScreen extends StatelessWidget {
  final String title;

  DetailScreen({required this.title});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
      ),
      body: Center(
        child: Text('This is the $title screen'),
      ),
    );
  }
}
